-- daves_sack / Options.lua
-- The Settings window opened by the Settings button: same Edit Mode chrome as
-- the bag window, laid out in two columns so it stays short. Built the first
-- time it's opened, so it costs nothing until used. Controls use Blizzard
-- templates where the client has them and fall back to plain widgets plus our
-- own art (Media\thumb) where it doesn't.

local ADDON, ns = ...
local M = ns.MEDIA
local floor, max, format = math.floor, math.max, string.format

local opt
local controls = {}
local WIDTH, HEIGHT = 470, 480
local LEFT_X, LEFT_W = 24, 200          -- left column
local RIGHT_X, RIGHT_W = 252, 194       -- right column
local FULL_W = WIDTH - 48

local function TryTemplate(kind, name, parent, template)
	local ok, f = pcall(CreateFrame, kind, name, parent, template)
	if ok and f then return f end
end

local function Sound(kit)
	if SOUNDKIT and SOUNDKIT[kit] then PlaySound(SOUNDKIT[kit]) end
end

local function Label(parent, text, font)
	local fs = parent:CreateFontString(nil, "ARTWORK", font or "GameFontNormal")
	fs:SetText(text)
	return fs
end

-- Gold section title with a divider running to the end of its column.
local function Header(text, x, y, width)
	local h = Label(opt, text, "GameFontNormal")
	h:SetPoint("TOPLEFT", x, y)
	local line = opt:CreateTexture(nil, "ARTWORK")
	line:SetColorTexture(1, 1, 1, 0.14); line:SetHeight(1)
	line:SetPoint("LEFT", h, "RIGHT", 8, 0)
	line:SetWidth(math.max(1, width - (h:GetStringWidth() or 0) - 8))
end

local function Tooltip(region, text)
	if not text then return end
	region:HookScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:SetText(text, 1, 1, 1, 1, true)
		GameTooltip:Show()
	end)
	region:HookScript("OnLeave", function() GameTooltip:Hide() end)
end

-- Slider: label on the left, live value on the right, bar underneath.
local function Slider(x, y, width, label, minV, maxV, step, fmt, get, set)
	local f = CreateFrame("Frame", nil, opt)
	f:SetSize(width, 40)
	f:SetPoint("TOPLEFT", x, y)
	f.label = Label(f, label, "GameFontHighlight"); f.label:SetPoint("TOPLEFT")
	f.value = Label(f, "", "GameFontNormal"); f.value:SetPoint("TOPRIGHT")

	local s = CreateFrame("Slider", nil, f)
	f.slider = s
	s:SetOrientation("HORIZONTAL")
	s:SetHeight(20)
	s:SetPoint("BOTTOMLEFT"); s:SetPoint("BOTTOMRIGHT")
	-- A limit may be a function: the window's hard size limits move with the
	-- screen, the gold and the reagent bag, so they're re-read on every Refresh.
	local function Bounds()
		local lo = type(minV) == "function" and minV() or minV
		local hi = type(maxV) == "function" and maxV() or maxV
		return lo, max(lo, hi)
	end
	s:SetMinMaxValues(Bounds())
	s:SetValueStep(step)
	if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
	s:SetThumbTexture(M .. "thumb")
	local th = s:GetThumbTexture(); if th then th:SetSize(16, 22) end
	local edge = s:CreateTexture(nil, "BACKGROUND", nil, -1)
	edge:SetColorTexture(0.35, 0.35, 0.38, 1)
	edge:SetPoint("LEFT", -1, 0); edge:SetPoint("RIGHT", 1, 0); edge:SetHeight(8)
	local bg = s:CreateTexture(nil, "BACKGROUND")
	bg:SetColorTexture(0, 0, 0, 0.85)
	bg:SetPoint("LEFT"); bg:SetPoint("RIGHT"); bg:SetHeight(6)

	s:EnableMouseWheel(true)
	s:SetScript("OnMouseWheel", function(self, d)
		if self.IsEnabled and not self:IsEnabled() then return end
		self:SetValue(self:GetValue() + d * step)
	end)
	s:SetScript("OnValueChanged", function(_, v)
		v = floor(v / step + 0.5) * step
		f.value:SetText(fmt(v))
		if not f.syncing and v ~= get() then set(v) end
	end)

	function f:Refresh()
		self.syncing = true
		s:SetMinMaxValues(Bounds())
		local v = get()
		s:SetValue(v); self.value:SetText(fmt(v))
		self.syncing = false
	end
	function f:SetActive(on)
		if on and s.Enable then s:Enable() elseif not on and s.Disable then s:Disable() end
		s:EnableMouse(on); s:EnableMouseWheel(on)
		self:SetAlpha(on and 1 or 0.4)
	end
	controls[#controls + 1] = f
	return f
end

local function Check(x, y, width, label, get, set, tip, size)
	local cb = TryTemplate("CheckButton", nil, opt, "UICheckButtonTemplate")
	if not cb then
		cb = CreateFrame("CheckButton", nil, opt)
		cb:SetNormalTexture("Interface\\Buttons\\UI-CheckBox-Up")
		cb:SetPushedTexture("Interface\\Buttons\\UI-CheckBox-Down")
		cb:SetHighlightTexture("Interface\\Buttons\\UI-CheckBox-Highlight", "ADD")
		cb:SetCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check")
	end
	cb:SetSize(size or 26, size or 26)
	cb:SetPoint("TOPLEFT", x - 4, y)
	local builtIn = cb.Text or cb.text
	if builtIn then builtIn:SetText("") end
	local fs = Label(cb, label, "GameFontHighlight")
	fs:SetPoint("LEFT", cb, "RIGHT", 2, 1)
	fs:SetWidth(width - 30); fs:SetJustifyH("LEFT")
	if fs.SetWordWrap then fs:SetWordWrap(false) end
	cb:SetHitRectInsets(0, -(width - 30), 0, 0)          -- the label is clickable too
	cb:SetScript("OnClick", function(self)
		Sound(self:GetChecked() and "IG_MAINMENU_OPTION_CHECKBOX_ON" or "IG_MAINMENU_OPTION_CHECKBOX_OFF")
		set(self:GetChecked() and true or false)
	end)
	Tooltip(cb, tip)
	function cb:Refresh() self:SetChecked(get() and true or false) end
	function cb:SetActive(on)
		if on and self.Enable then self:Enable() elseif not on and self.Disable then self:Disable() end
		self:SetAlpha(on and 1 or 0.4)
	end
	controls[#controls + 1] = cb
	return cb
end

local function PanelButton(text, width)
	local b = TryTemplate("Button", nil, opt, "UIPanelButtonTemplate")
	if not b then
		b = CreateFrame("Button", nil, opt)
		local t = b:CreateTexture(nil, "BACKGROUND"); t:SetColorTexture(0.45, 0.08, 0.06, 1); t:SetAllPoints()
		b:SetNormalFontObject("GameFontNormal")
		local hl = b:CreateTexture(nil, "HIGHLIGHT"); hl:SetColorTexture(1, 1, 1, 0.08); hl:SetAllPoints()
	end
	b:SetText(text)
	b:SetSize(width, 22)
	return b
end

-- Dropdown: label on the left, Blizzard's styled dropdown underneath (its menu is
-- a radio list of the items). Where the client has no menu system, a button that
-- cycles through the items instead.
local function Dropdown(x, y, width, label, items, get, set, tip)
	local f = CreateFrame("Frame", nil, opt)
	f:SetSize(width, 46)
	f:SetPoint("TOPLEFT", x, y)
	f.label = Label(f, label, "GameFontHighlight"); f.label:SetPoint("TOPLEFT")
	local function Current()
		for _, it in ipairs(items) do if it.key == get() then return it end end
		return items[1]
	end
	local dd = TryTemplate("DropdownButton", nil, f, "WowStyle1DropdownTemplate")
	if dd and dd.SetupMenu then
		dd:SetPoint("BOTTOMLEFT", 0, 0); dd:SetWidth(width)
		-- the button's text is the selected radio's; the saved item's name is also its default text, so the
		-- saved choice shows the moment Settings opens, before and without any menu selection
		local function Show() if dd.SetDefaultText then dd:SetDefaultText(Current().name) end end
		dd:SetupMenu(function(_, root)
			for _, it in ipairs(items) do
				root:CreateRadio(it.name, function() return get() == it.key end, function() set(it.key); Show() end)
			end
		end)
		function f:Refresh() Show(); dd:GenerateMenu() end
		Show()
		Tooltip(dd, tip)
	else
		local b = TryTemplate("Button", nil, f, "UIPanelButtonTemplate") or CreateFrame("Button", nil, f)
		b:SetPoint("BOTTOMLEFT", 0, 0); b:SetSize(width, 22)
		if not b.SetText then b.text = Label(b, "", "GameFontHighlight"); b.text:SetPoint("CENTER"); b.SetText = function(_, t) b.text:SetText(t) end end
		b:SetScript("OnClick", function()
			local cur = Current()
			for i, it in ipairs(items) do
				if it == cur then set(items[i % #items + 1].key); break end
			end
			b:SetText(Current().name)
		end)
		function f:Refresh() b:SetText(Current().name) end
		Tooltip(b, tip)
	end
	Tooltip(f.label, tip)
	controls[#controls + 1] = f
	return f
end

local function RefreshAll()
	for _, c in ipairs(controls) do c:Refresh() end
	if controls.height then controls.height:SetActive(ns.db.viewHeight ~= nil) end
	local catsOn = not ns.db.oneBag
	for _, cb in ipairs(controls.catControls or {}) do
		cb:SetActive(catsOn)
	end
	if controls.lockSets then
		controls.lockSets:SetActive(catsOn and ns.db.splitEquipment ~= false)
	end
	local splitOn = catsOn and ns.db.splitConsumables ~= false
	for _, cb in ipairs(controls.consGroups or {}) do
		cb:SetActive(splitOn)
	end
end

local function Build()
	opt = CreateFrame("Frame", "DavesSackOptions", UIParent)
	opt:SetSize(WIDTH, HEIGHT)
	opt:SetFrameStrata("DIALOG")
	opt:SetClampedToScreen(true)
	opt:EnableMouse(true); opt:SetMovable(true); opt:RegisterForDrag("LeftButton")
	if opt.SetDontSavePosition then opt:SetDontSavePosition(true) end
	opt:SetScript("OnDragStart", opt.StartMoving)
	opt:SetScript("OnDragStop", opt.StopMovingOrSizing)
	opt:Hide()
	tinsert(UISpecialFrames, "DavesSackOptions")

	local border = TryTemplate("Frame", nil, opt, "DialogBorderTranslucentTemplate")
	if border then
		border:SetAllPoints()
	else
		border = CreateFrame("Frame", nil, opt, BackdropTemplateMixin and "BackdropTemplate" or nil)
		border:SetAllPoints(); border:SetFrameLevel(opt:GetFrameLevel())
		border:SetBackdrop({
			bgFile = "Interface\\Buttons\\WHITE8X8",
			edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", edgeSize = 32,
			insets = { left = 11, right = 12, top = 12, bottom = 11 },
		})
		border:SetBackdropColor(0, 0, 0, 0.8)
	end
	ns.optionsBorder = border
	ns.ApplyBackground()

	local title = Label(opt, "Bag Settings", "GameFontHighlightLarge")
	title:SetPoint("TOP", 0, -15)

	local close = TryTemplate("Button", nil, opt, "UIPanelCloseButton")
	if close then
		close:SetPoint("TOPRIGHT")
	else
		close = CreateFrame("Button", nil, opt)
		close:SetSize(32, 32); close:SetPoint("TOPRIGHT", 2, 2)
		close:SetNormalTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Up")
		close:SetPushedTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Down")
		close:SetHighlightTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight", "ADD")
	end
	close:SetFrameLevel(opt:GetFrameLevel() + 5)
	close:SetScript("OnClick", function() opt:Hide() end)

	local db = ns.db

	-- Left column: Size ------------------------------------------------------
	Header("Size", LEFT_X, -50, LEFT_W)
	Slider(LEFT_X, -72, LEFT_W, "Columns", ns.MinColumns, ns.MaxColumns, 1,
		function(v) return format("%d", v) end,
		function() return db.columns end,
		function(v) db.columns = ns.ClampColumns(v); ns.Relayout() end)
	Slider(LEFT_X, -120, LEFT_W, "Scale", 0.5, 2, 0.05,
		function(v) return format("%d%%", floor(v * 100 + 0.5)) end,
		function() return db.scale end,
		function(v) db.scale = v; ns.ApplyScale() end)
	Check(LEFT_X, -166, LEFT_W, "Fit height to my items",
		function() return db.viewHeight == nil end,
		function(on)
			db.viewHeight = (not on) and ns.ClampViewHeight(ns.CurrentViewHeight()) or nil
			ns.Relayout(); RefreshAll()
		end,
		"The window fits your items each time you open your bags (up to 80% of the screen), then keeps that size while open: new items scroll instead of resizing it. Untick to set your own height.")
	controls.height = Slider(LEFT_X, -196, LEFT_W, "Height", ns.MIN_VIEW, ns.MaxViewHeight, 10,
		function(v) return format("%d", v) end,
		function() return db.viewHeight or floor(ns.CurrentViewHeight() + 0.5) end,
		function(v) db.viewHeight = ns.ClampViewHeight(v); ns.ApplyView() end)

	-- Left column: Look -------------------------------------------------------
	Header("Look", LEFT_X, -246, LEFT_W)
	Slider(LEFT_X, -268, LEFT_W, "Background", 0.2, 1, 0.05,
		function(v) return format("%d%%", floor(v * 100 + 0.5)) end,
		function() return db.background or 0.8 end,
		function(v) db.background = v; ns.ApplyBackground() end)
	Dropdown(LEFT_X, -314, LEFT_W, "Background style", ns.BACKGROUND_STYLES,
		function() return db.backgroundStyle or "dark" end,
		function(key) db.backgroundStyle = key; ns.ApplyBackground() end,
		"Which of Blizzard's standard backgrounds shows behind your items, at the darkness set above. The Settings window follows it too.")

	-- Right column: Categories + Extras ---------------------------------------
	local y = -50
	controls.catControls = {}
	Header("Categories", RIGHT_X, y, RIGHT_W); y = y - 20
	Check(RIGHT_X, y, RIGHT_W, "One big bag",
		function() return db.oneBag and true or false end,
		function(on) db.oneBag = on; ns.Relayout(); RefreshAll() end,
		"Show every slot of your bags (filled and empty) in one continuous grid in bag/slot order instead of sorting items into categories.")
	y = y - 26
	controls.catControls[#controls.catControls + 1] = Check(RIGHT_X, y, RIGHT_W, "Equipment item sets",
		function() return db.splitEquipment ~= false end,
		function(on)
			db.splitEquipment = on
			if ns.RecategorizeEquipment then ns.RecategorizeEquipment() else ns.Relayout() end
			RefreshAll()
		end,
		"Split Equipment into Item Sets and Other Equipment. Drag any weapon or armor onto the Item Sets header to add or remove it from Item Sets.")
	y = y - 24
	controls.lockSets = Check(RIGHT_X + 20, y, RIGHT_W - 20, "Lock item sets",
		function() return db.lockItemSets and true or false end,
		function(on)
			if ns.SetItemSetsLocked then ns.SetItemSetsLocked(on) else db.lockItemSets = on end
		end,
		"Lock all items in Item Sets so they cannot be sold to vendors, traded, mailed, auctioned, or deleted. Unlock when you want to equip or move set gear.", 22)
	y = y - 24
	controls.catControls[#controls.catControls + 1] = Check(RIGHT_X, y, RIGHT_W, "Reagents by profession",
		function() return db.splitReagents ~= false end,
		function(on) db.splitReagents = on; ns.Relayout() end,
		"Tailoring, Mining, Herbalism… Main professions win over Cooking and First Aid (linen stays under Tailoring).")
	y = y - 26
	controls.catControls[#controls.catControls + 1] = Check(RIGHT_X, y, RIGHT_W, "Consumables by type",
		function() return db.splitConsumables ~= false end,
		function(on) db.splitConsumables = on; ns.Relayout(); RefreshAll() end,
		"Split Consumables into the groups below. Untick a group to move its items into Other Consumables.")
	y = y - 24
	-- one switch per consumable group (indented under "Consumables by type")
	controls.consGroups = {}
	for _, g in ipairs(ns.CONSUMABLE_GROUPS) do
		local cb = Check(RIGHT_X + 20, y, RIGHT_W - 20, ns.GROUP_NAMES[g],
			function() return not db.offGroups[g] end,
			function(on) db.offGroups[g] = (not on) or nil; ns.Relayout() end,
			"Untick to show these under Other Consumables instead.", 22)
		controls.consGroups[#controls.consGroups + 1] = cb
		y = y - 22
	end

	y = y - 16
	Header("Extras", RIGHT_X, y, RIGHT_W); y = y - 20
	Check(RIGHT_X, y, RIGHT_W, "Confirm delete (trash)",
		function() return db.confirmDestroy ~= false end,
		function(on)
			db.confirmDestroy = on
			if not on and ns.HideDestroyConfirm then ns.HideDestroyConfirm() end
		end,
		"Ask before destroying an item dropped on the delete / trash button (rare and better items ask you to type DELETE). Untick to destroy items immediately.")
	y = y - 26
	local cur = Check(RIGHT_X, y, RIGHT_W, "Backpack currencies",
		function() return db.showCurrencies ~= false end,
		function(on) db.showCurrencies = on; ns.RefreshCurrencies() end,
		ns.HasCurrencyAPI and "Currencies you ticked \"Show on Backpack\" in the Currency tab appear in the footer."
			or "This version of the game has no currencies.")
	if not ns.HasCurrencyAPI then
		cur:SetActive(false)
	end
	y = y - 26
	Check(RIGHT_X, y, RIGHT_W, "Auction House prices",
		function() return db.showAuctionPrices ~= false end,
		function(on)
			db.showAuctionPrices = on
			if ns.RefreshAuctionFooter then ns.RefreshAuctionFooter() end
		end,
		"Cache item prices when you visit or browse the Auction House, show unit and stack prices on item tooltips, and show your bags' tradeable AH value and last update time at the bottom of the window.")
	y = y - 26
	controls.catControls[#controls.catControls + 1] = Check(RIGHT_X, y, RIGHT_W, "Free Space tile",
		function() return db.showFreeSpace ~= false end,
		function(on) db.showFreeSpace = on; ns.Relayout() end,
		"An empty slot to drop items on. You can also drop items anywhere on the bag window.")
	y = y - 26
	Check(RIGHT_X, y, RIGHT_W, "Auto-place split stacks",
		function() return db.autoPlaceSplit ~= false end,
		function(on) db.autoPlaceSplit = on end,
		"After you split a stack, the new stack goes straight into a free slot next to the original. Paused while a merchant, mailbox, trade, bank or auction window is open, so you can drop it there.")
	y = y - 26
	local reagent = Check(RIGHT_X, y, RIGHT_W, "Prefer the reagent bag",
		function() return db.preferReagentBag ~= false end,
		function(on) db.preferReagentBag = on end,
		ns.REAGENT_BAG and "Reagents you drop on the window (and split reagent stacks) go into your reagent bag first, while it has room. Everything else goes into your bags."
			or "This version of the game has no reagent bag.")
	if not ns.REAGENT_BAG then
		reagent:SetActive(false)
	end
	y = y - 26

	-- Full width: Start collapsed (3 columns) ---------------------------------
	local foldY = math.min(-360, y) - 20          -- below whichever column is longer
	Header("Start collapsed", LEFT_X, foldY, FULL_W)
	local names = {}
	for i, n in ipairs(ns.CATEGORY_NAMES) do names[i] = n end
	names[#names + 1] = "Free Space"
	local colW = floor(FULL_W / 3)
	for i, name in ipairs(names) do
		local col, row = (i - 1) % 3, floor((i - 1) / 3)
		controls.catControls[#controls.catControls + 1] = Check(LEFT_X + col * colW, foldY - 20 - row * 26, colW, name,
			function() return db.startFolded[i] end,
			function(on)
				db.startFolded[i] = on or nil
				db.collapsed[i] = on or nil          -- apply right away too
				ns.Relayout()
			end)
	end

	-- Reset --------------------------------------------------------------------
	local resetY = foldY - 20 - (floor((#names - 1) / 3) + 1) * 26 - 18
	Header("Reset", LEFT_X, resetY, FULL_W)
	local resetPos = PanelButton("Reset Position", 140)
	resetPos:SetPoint("TOPLEFT", LEFT_X, resetY - 22)
	resetPos:SetScript("OnClick", function()
		db.pos = nil; ns.ResetPosition()
	end)
	local defaults = PanelButton("Restore Defaults", 150)
	defaults:SetPoint("TOPRIGHT", -24, resetY - 22)
	defaults:SetScript("OnClick", function()
		db.columns, db.scale, db.viewHeight, db.pos, db.background, db.backgroundStyle = ns.ClampColumns(10), 1, nil, nil, 0.8, "dark"
		db.oneBag, db.splitEquipment, db.splitReagents, db.splitConsumables = false, true, true, true
		if ns.SetItemSetsLocked then ns.SetItemSetsLocked(false) else db.lockItemSets = false end
		db.showCurrencies, db.showAuctionPrices, db.showFreeSpace, db.autoPlaceSplit, db.preferReagentBag, db.confirmDestroy = true, true, true, true, true, true
		wipe(db.collapsed); wipe(db.startFolded); wipe(db.offGroups)
		if db.customSetItems then wipe(db.customSetItems) end
		ns.ApplyScale(); ns.ApplyBackground(); ns.ResetPosition(); ns.Relayout(); ns.RefreshCurrencies()
		if ns.RefreshAuctionFooter then ns.RefreshAuctionFooter() end
		RefreshAll()
	end)

	local tips = Label(opt, ns.TIPS or "", "GameFontDisableSmall")
	tips:SetPoint("TOPLEFT", LEFT_X, resetY - 58); tips:SetWidth(FULL_W)
	tips:SetJustifyH("LEFT")
	if tips.SetWordWrap then tips:SetWordWrap(true) end
	opt:SetHeight(-(resetY - 58) + max(36, (tips:GetStringHeight() or 36)) + 20)

	opt:SetScript("OnShow", function()
		Sound("IG_MAINMENU_OPEN")
		if ns.SyncSettingsButton then ns.SyncSettingsButton() end
		RefreshAll()
	end)
	opt:SetScript("OnHide", function()
		if ns.SyncSettingsButton then ns.SyncSettingsButton() end
		Sound("IG_MAINMENU_CLOSE")
	end)
end

function ns.IsOptionsOpen()
	return opt ~= nil and opt:IsShown()
end

-- Open next to the bags (on whichever side has room).
local function Place()
	opt:ClearAllPoints()
	local bags = ns.frame
	local left = bags and bags:IsShown() and bags:GetLeft()
	if left then
		local roomLeft = left * bags:GetEffectiveScale() / opt:GetEffectiveScale()
		if roomLeft > WIDTH + 20 then
			opt:SetPoint("TOPRIGHT", bags, "TOPLEFT", -10, 0)
		else
			opt:SetPoint("TOPLEFT", bags, "TOPRIGHT", 10, 0)
		end
	else
		opt:SetPoint("CENTER")
	end
	-- Detach from the bag window: otherwise dragging Columns/Scale moves the
	-- bags, the Settings window moves with them, and the slider runs away.
	local l, t = opt:GetLeft(), opt:GetTop()
	if l and t then
		opt:ClearAllPoints()
		opt:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", l, t)
	end
end

function ns.ToggleOptions()
	if not opt then Build() end
	if opt:IsShown() then opt:Hide() else Place(); opt:Show() end
end

-- Keeps the controls in step when the bag window is resized by its corners.
function ns.RefreshOptions()
	if opt and opt:IsShown() then RefreshAll() end
end

-- Also register a page in Blizzard's Settings panel (Esc > Options > AddOns)
-- so players looking in standard AddOn options find Confirm delete (trash) and
-- core bag toggles right away. Full layout & category controls live in the bag
-- window's Settings button (/sack options).
function ns.InitSettingsPanel()
	if not (Settings and Settings.RegisterVerticalLayoutCategory) then return end

	local category = Settings.RegisterVerticalLayoutCategory("Dave's Sack")

	local oneBag = Settings.RegisterAddOnSetting(category, ADDON .. "_oneBag", "oneBag", ns.db,
		Settings.VarType.Boolean, "One big bag", false)
	Settings.CreateCheckbox(category, oneBag,
		"Show every slot of your bags (filled and empty) in one continuous grid in bag/slot order instead of sorting items into categories.")
	oneBag:SetValueChangedCallback(function()
		ns.Relayout()
		ns.RefreshOptions()
	end)

	local confirm = Settings.RegisterAddOnSetting(category, ADDON .. "_confirmDestroy", "confirmDestroy", ns.db,
		Settings.VarType.Boolean, "Confirm delete (trash)", true)
	Settings.CreateCheckbox(category, confirm,
		"Ask before destroying an item dropped on the delete / trash button (rare and better items ask you to type DELETE). Untick to destroy items immediately. Click the Settings button on the bag window (/sack options) for layout and category settings.")
	confirm:SetValueChangedCallback(function()
		if not ns.db.confirmDestroy and ns.HideDestroyConfirm then ns.HideDestroyConfirm() end
		ns.RefreshOptions()
	end)

	local freeSpace = Settings.RegisterAddOnSetting(category, ADDON .. "_showFreeSpace", "showFreeSpace", ns.db,
		Settings.VarType.Boolean, "Free Space tile", true)
	Settings.CreateCheckbox(category, freeSpace,
		"An empty slot to drop items on. You can also drop items anywhere on the bag window.")
	freeSpace:SetValueChangedCallback(function()
		ns.Relayout()
		ns.RefreshOptions()
	end)

	local autoSplit = Settings.RegisterAddOnSetting(category, ADDON .. "_autoPlaceSplit", "autoPlaceSplit", ns.db,
		Settings.VarType.Boolean, "Auto-place split stacks", true)
	Settings.CreateCheckbox(category, autoSplit,
		"After you split a stack, the new stack goes straight into a free slot next to the original. Paused while a merchant, mailbox, trade, bank or auction window is open.")
	autoSplit:SetValueChangedCallback(function()
		ns.RefreshOptions()
	end)

	local ahPrices = Settings.RegisterAddOnSetting(category, ADDON .. "_showAuctionPrices", "showAuctionPrices", ns.db,
		Settings.VarType.Boolean, "Auction House prices", true)
	Settings.CreateCheckbox(category, ahPrices,
		"Cache item prices when you visit or browse the Auction House, show unit and stack prices on item tooltips, and show your bags' tradeable AH value and last update time at the bottom of the window.")
	ahPrices:SetValueChangedCallback(function()
		if ns.RefreshAuctionFooter then ns.RefreshAuctionFooter() end
		ns.RefreshOptions()
	end)

	if ns.HasCurrencyAPI then
		local cur = Settings.RegisterAddOnSetting(category, ADDON .. "_showCurrencies", "showCurrencies", ns.db,
			Settings.VarType.Boolean, "Backpack currencies", true)
		Settings.CreateCheckbox(category, cur,
			"Currencies you ticked \"Show on Backpack\" in the Currency tab appear in the footer.")
		cur:SetValueChangedCallback(function()
			ns.RefreshCurrencies()
			ns.RefreshOptions()
		end)
	end

	if ns.REAGENT_BAG then
		local reagent = Settings.RegisterAddOnSetting(category, ADDON .. "_preferReagentBag", "preferReagentBag", ns.db,
			Settings.VarType.Boolean, "Prefer the reagent bag", true)
		Settings.CreateCheckbox(category, reagent,
			"Reagents you drop on the window (and split reagent stacks) go into your reagent bag first, while it has room.")
		reagent:SetValueChangedCallback(function()
			ns.RefreshOptions()
		end)
	end

	Settings.RegisterAddOnCategory(category)
	ns.settingsCategory = category
end
