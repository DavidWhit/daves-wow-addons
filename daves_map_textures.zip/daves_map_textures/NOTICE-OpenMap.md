# Where these textures come from

OpenMap draws no art of its own. Every texture here is either cut from World of
Warcraft's own map art (Blizzard Entertainment's, not covered by OpenMap's MIT
licence), generated from noise, or (one folder, below) drawn by a player who lets
OpenMap use it. Each is made by a script in `tools/`, so it
can be rebuilt from the game's files; the few touched by hand (marked below) are
Blizzard's art edited by hand, kept in `art/edits/`.

**OpenMap's own icon**: `OpenMapIcon` and `OpenMapIconRound` (cut to the gold ring) (shared by both clients, in `Media/Textures/`: the AddOns list,
the minimap button, the map's menu and portrait) is OpenMap's own picture, not Blizzard's: a map scroll
in a gold ring, drawn by zloyeb and used with his permission (not covered by OpenMap's MIT licence),
shrunk from `art/icon/openmap.png` by `tools/icon/build.py`.

The shared `GroupRing.tga` uses Blizzard's `WhiteCircle-RaidBlips` sprite from the
Forever atlas (file data ID 1523129). `tools/icon/group_ring.py` composites the
original pin's tinted layers and clears the center for Blizzard's dot.

**From Blizzard's art** (crops, colour fields and shapes taken from the game's map textures):

| Texture | What it is | Made by |
| --- | --- | --- |
| `MapSeaDark`, `MapSeaLight` | the open sea's crackled paper, from the client's high-resolution Eastern Kingdoms overview map (its hatching painted out) | `tools/map-preview/sea.py` |
| `MapSeaField/` | the sea's colour, smoothed from the world and continent maps | `tools/map-preview/sea.py` |
| `MapHatch` | the coastal wave strokes, from the Kalimdor continent map | `tools/map-preview/sea.py` |
| `MapPaper` | blank map parchment, from Westfall's zone map | `tools/map-preview/gapfill.py` |
| `MapLand/` | smooth colour fields of the continent maps' land | `tools/map-preview/render.py --bake-land` |
| `MapBand/`, `MapCore/`, `MapTerritory/`, `MapEdge/` | masks traced from each zone map's shape and frame | `tools/map-grade`, `tools/map-preview` |
| `MapZoneLand/` | each zone map's land without the sea it paints (its territory less that sea, found by colour; shared out where neighbours overlap), for darkening unexplored land | `tools/map-preview/render.py --bake-zone-land` |
| `MapZoneBorder/` | each zone's share of the land round it that's no zone's (border mountains, land between zones), from the continent map's land and the zones' land masks | `tools/map-preview/render.py --bake-zone-land` |
| `MapMiniLand/` | where the close-up minimap shows: each continent map's land and its zone maps' own land (`MapLand` and `MapZoneLand` put together, finer) | `tools/map-preview/render.py --bake-mini-land` |
| `MapCave/` | masks traced from the cave maps, and from where the caves' own rooms lie (the game's WMOs) | `tools/map-caves/build.py` (`wmo.py`) |
| `MapGapPlace/` | masks of the places a painted gap shows that no zone map draws (WoW Forever's Excavation Site in the Wetlands): the ground the game's terrain gives the place's area, where the painting shows | `tools/map-preview/gapplaces.py` |
| `MapCoast/`, `MapSeaMask/`, `MapGapLand/`, `MapGapMask/`, `MapBackLand/` | masks traced from the continent maps' coasts | `tools/map-preview/sea.py`, `gapfill.py` |
| `MapSeaOut/`, `MapSeaOpen/`, `MapSeaCoast/` | masks of the world and continent maps' sea: past the world map's edge, and its coastal hatching apart from its open sea | `tools/map-preview/sea_world.py` |
| `MapBanner/` | a zone map's name banner for a city ("Orgrimmar" on Durotar's, and Tirisfal's, Mulgore's and Teldrassil's for their cities), cut out along a traced outline | `tools/map-preview/banners.py` |
| `MapBannerHole/`, `MapCityMask/` | masks traced on the art: the zone's art without that banner, and a city's map cut down to the city and its name banner | `tools/map-preview/banners.py` |
| `MapGapLand/` (Gilneas), `MapCoastArt/` | masks for Blizzard's own maps that the client has but Forever's tables don't use (Gilneas' base map; the classic base maps of 16 zones, which paint the land round them): where they're drawn, at their own resolution, on land no zone covers | `tools/map-preview/gapfill.py` |
| `MapMiniLOD/` | the game's minimap tiles, shrunk and laid side by side (16 and 64 px a tile), tinted as the close-up minimap is | `tools/map-preview/minimaplod.py` |
| `MapZones/` | every zone map composited onto the world as the map draws it at full detail (each zone's base art and overlays through its masks, the colour-match copies, the interiors, the gaps' finer maps), in 512-px tiles, BLP with DXT5 compression; `MapZones/ptBR/`: the same from the Brazilian Portuguese client's own art (its place names and city banners in its language) | `tools/map-preview/render.py --bake-zones` (`OPENMAP_LOCALE=ptBR` with `OPENMAP_WOW` on a ptBR install) |
| `MapArt/` | world and continent map tiles with their sea and continent names painted out (by hand) | `tools/map-art/import.py` |
| `MapTile/` | the game's own cave and dungeon map tiles, and the tiles of its unexplored map of Gilneas (`308492`-`308503`, drawn in the gap where Gilneas is: #152), copied as they are (`<file ID>.blp`): WoW Forever doesn't list them for every language, so some clients (esMX, ruRU, itIT) drew them green. RADD95's OpenMap TextureFix (MIT) found this and fixed it first | `tools/map-tiles/build.py` |
| `MapCaveMend/` | the game's own cave minimap pictures where a fault is baked into the file, mended (`215101.tga`: md_mushroomcave08's, an opaque white block over its tunnel's mouth made clear), drawn instead of the game's | `tools/map-caves/minimap.py` (`MEND`) |
| `MapDungeonMinimap/` | maps of WoW Forever's own dungeons laid out from the game's own minimap pictures of their rooms (WMOMinimapTexture) and, outdoors, of their terrain, where each room is, a picture per floor (floors set in `tools/map-dungeons/minimap.json`): Ruins of Lordaeron (`2999_*`), The Hall of Thanes (`3065_*`); in the dungeon map layout, 4 x 3 tiles of 256 px | `tools/map-dungeons/minimap.py` |

**Drawn for WoW Forever's own dungeons** (the game has no map of them), used with the artist's
permission, credited on the map in game, and not covered by OpenMap's MIT licence:

| Texture | What it is | Made by |
| --- | --- | --- |
| `MapDungeonDrawn/` | maps of City of Dalaran (`2959_*`) and its Underbelly (`dalaran-the-underbelly_*`), Blackmaw Hold's six floors (`2974_*`, `blackmaw-hold-*`), Excavation Site: Wetlands (`2998_*`), Ruins of Lordaeron (`2999_*`), The Hall of Thanes (`3065_*`), The Drowned City (`the-drowned-city_*`), Krol'dok Stronghold (`kroldok-stronghold_*`) and Shaper's Terrace with the Prismatic Talus (`shapers-terrace_*`, `prismatic-talus_*`), drawn by Santiago Reyes (<https://sreyesmaps.com/post/proyecto-atlas-de-azeroth-forever>; originals in `art/drawn/dungeons/`), in the dungeon map layout: 4 x 3 tiles of 256 px | `tools/map-dungeons/drawn.py` |
| `MapChart/` | the sea chart round the world map (Options' Responsive ocean & border), painted by Santiago Reyes (originals in `art/drawn/chart/`): his paper and sea, the dark ground under it (made to tile), his navigation lines (each compass rose's rays apart), his ornaments and frame corners, each cut out on its own; with them two cross-fade masks for the paper's seams (`SeamX`, `SeamY`, generated) and `Middle`, a mask of the game's world map in the chart (from `MapFeatherWide` and `MapBackLand/947`) | `tools/map-chart/build.py` |
| `MapGapFill/` | land no zone map covers, painted by hand by Santiago Reyes in the zone maps' style from Blizzard's own art, following the game's minimap (originals in `art/drawn/gaps/`), cut to that land and tiled; with it, the `MapZones/` tiles it shows in | `tools/map-preview/gapfills.py` |

**Generated** (no game art in them): `MapGrain`, `MapTooth` (paper grain, from noise)
and the `MapFeather*` edge masks (`tools/map-textures/make.py`).
